/*
 * Author(s): <Nan Kang>
 * e-mail   : kangnan95@qq.com
 * Implementation of a Unix-like file system.
*/
#include "util.h"
#include "common.h"
#include "block.h"
#include "fs.h"

#ifdef FAKE
#include <stdio.h>
#define ERROR_MSG(m) printf m;
#else
#define ERROR_MSG(m)
#endif

#define CEIL(a,b) ((a)+(b)-1)/(b)
#define MIN(a,b)  (((a)>(b))?(b):(a))
#define MAX(a,b)  (((a)>(b))?(b):(a))

/* super block */
#define SB_LOC  0
#define SB_SIZE 1
#define SB_MAGIC_NUMER 9929062
#define SB_CPY_LOC FS_SIZE-1    //last block
static sb_t* sblock;
static sb_t* sblock_cpy;
static char sb_buf[BLOCK_SIZE];

/* bitmap */
#define MAP_LOC  (SB_LOC+SB_SIZE)

/* inode_table */
#define MAX_INODE_NUM 1024       //
#define INODE_START   (MAP_LOC+MAP_SIZE)
#define INODES_PER_BLOCK (BLOCK_SIZE/sizeof(inode_t))
// char read_buf [BLOCK_SIZE];
// char read_buf2[BLOCK_SIZE];
// #define INOTAB_SIZE 

/* file descriptor table */
#define FD_SIZE 64
fd_t fd_table[FD_SIZE];

/* directory management */
#define ROOT_ADDR 0
inode_t *root_inode;
int     current_directory;
// char dir_buf[BLOCK_SIZE];


void my_strcpy(char* src,char* dest){
    int i=0;
    while(src[i]!='\0'){
        dest[i]=src[i];
        i++;
    }
    dest[i]='\0';
}

int my_strcmp(char *a,char *b){
    int i=0;
    while(a[i]!='\0' && b[i]!='\0'){
        if(a[i]>b[i])
            return 1;
        else if(a[i]<b[i])
            return -1;
        else
            i++;
    }
    if(a[i]>b[i])
        return 1;
    else if(a[i]<b[i])
        return -1;
    else 
        return 0;
}

void bset(char *area, int size,char c)
{
    while (size) {
    area[--size] = c;
    }
}

/********************* superblock *********************/
void sblock_init(){
    sblock->magic_num   = SB_MAGIC_NUMER;   
    sblock->size        = FS_SIZE;          //number of sectors
    /* bitmap */
    sblock->map_start   = SB_LOC+1;
    sblock->map_blocks  = CEIL(MAX_INODE_NUM*sizeof(uint8_t),BLOCK_SIZE);    //each inode may need more than 
    /* inode */
    sblock->inode_start = sblock->map_start+sblock->map_start;
    sblock->inode_num   = MAX_INODE_NUM;
    sblock->inode_blocks= CEIL(MAX_INODE_NUM,BLOCK_SIZE/sizeof(inode_t)); //ceil_div(MAX_FILE_COUNT, BLOCK_SIZE/sizeof(inode_t));
    /* data */
    sblock->data_start  = sblock->inode_start+sblock->inode_blocks;
    sblock->data_blocks = FS_SIZE*BLOCK_SIZE/512-sblock->data_start-1; 
                         /* for example, there is 16 blocks,and start=3
                          * then 0 1 2 have been used,so 16-3=13 blocks remains.
                          * but the last blocks is for backup,so 16-3-1=12
                         */
}

void sblock_write(char *buf) {
    block_write(SB_LOC, buf);
    block_write(SB_CPY_LOC,buf);    //for copy version.
}

/*********************** bitmap ***********************/
int block_in_map(int ind){
/* index of block --> index in bitmap */
    return sblock->map_start + (ind*sizeof(uint8_t)/BLOCK_SIZE);
}

uint8_t* map_read(int index,char *buf){
    block_read(block_in_map(index),buf);
    /* bit of block(index) */
    return (uint8_t *)&(buf[index % BLOCK_SIZE]);
}

void map_write(int index, char *buf){
    block_write(block_in_map(index),buf);
}


/***********************  block ***********************/
int block_alloc(){
/* allocate a new block,and return block number */
    char buf[BLOCK_SIZE];
    for(int i=0; i<sblock->map_blocks; ++i){
        block_read(sblock->map_start+i,buf);
        for(int j=0; j<BLOCK_SIZE; ++j){
            if(buf[j]==0){
                buf[j]=1;   //used
                block_write(sblock->map_start+i,buf);
                return (i * BLOCK_SIZE) + j;
            }
        }
    }//EndFor map block
    return -1;
}

static void block_free(int index) {
    uint8_t *map_entry;
    char buf[BLOCK_SIZE];

    map_entry = map_read(index, buf);
    *map_entry = 0; // set as unused
    map_write(index, buf);    
}


// int block_alloc(){
//     /* return index of blcok,which start from 0 */
//     char    buf[BLOCK_SIZE];
//     int     ind=1;  //0 1 2 3 4 5 6 7
//     bool_t  found=FALSE;
//     for(int i=sblock->map_start;i<(sblock->map_start+sblock->map_blocks);++i){
//         /* read i-th block */
//         block_read(i,buf);
//         for(int j=0;j<BLOCK_SIZE;++j){
//             char bit=0x1;
//             while(bit){
//                 if(bit & buf[j])
//                     break;
//                 ind++;
//                 bit=bit<<1;
//             }
//             if(bit){
//                 found=TRUE;
//                 break;
//             }
//         }// Forall bit in a block
//         if(found)
//             break;
//     }//Forall blocks
//     if(found)
//         return ind;
//     else
//         return -1;
// }

/************************ inode ************************/
int inode_init(inode_t* inode,short type){
    /*ino starts from 1*/
    // static int node_index=1;
    // inode->ino    = node_index++;
    inode->size   = 0;
    inode->type   =type;
    inode->nlink  =1;  
    inode->nblock =0;
    inode->n_open =0;
    for(int i=0;i<D_BLOCK;++i){
        inode->blocks[i]=0x0;
    }
    // if(inode->type==DIRECTORY){
    //      allocate one block for directory which contains dir_t structure 

    // }
    return 0;
}

inode_t* inode_read(int k,char* buf){
/* using a static array: buf */
/* read k-th inode, whose ino is k+1. k start from 0. */
/* assume there is 16 inode in one block,then
    e.g k=15,then block_index =15/16=0
                  inode_offset=15%16=15   15 can be the index of array    
 */
    inode_t *p = (inode_t*)buf;
    int block_index = k/INODES_PER_BLOCK;  // 0 1 2 3...
    int inode_offset= k%INODES_PER_BLOCK;  // 0 1 2 3...
    block_read(sblock->inode_start+block_index,buf);
    p=p+inode_offset;    //finding the inode
    return p;
}

void inode_write(int k,char* buf){
/* using a static array: buf 
 * 'inode' in inode_read() is given a addr of buf,
 * after that its content may be changed(it means read_buf changes),
 * so just write the buf back.   
 */
    int block_index = k/INODES_PER_BLOCK;  // 0 1 2 3...
    // int inode_offset= k%INODES_PER_BLOCK;  // 0 1 2 3...
    block_write(sblock->inode_start+block_index,buf);
}


int inode_create(int type){
/* don't use inode bitmap,so the only method is to search all inode... */
    char buf[BLOCK_SIZE];   // for read inode
    inode_t* inode;     //pointer to each inode
    // for each inode-block i
    inode = (inode_t *)buf;
    for(int i=0;i<sblock->inode_num;++i){
        block_read(sblock->inode_start+i,buf);
        //for each inode in block i
        for(int j=0;j<INODES_PER_BLOCK;++j){
            if(inode[j].type == FREE_INODE){
                // find a free inode
                inode_init(&inode[j],type);
                inode[j].ino = i *INODES_PER_BLOCK + j; //ino
                //write back
                block_write(sblock->inode_start+i,buf);
                return inode[j].ino;
            }
        }//EndFor inode
    }//EndFor block
    // no free inode
    return -1;
}

// int inode_alloc(){
//     /* return -1 iff there is no free node */
//     inode_t *p;
//     for(int k=0;k<MAX_INODE_NUM;++k){
//         p=inode_read(k,read_buf);
//         if(p->is_free==TRUE)
//             return p->ino;
//     }    
//     return -1;  
// }

void inode_free(int ino){
    inode_t* inode;
    char buf[BLOCK_SIZE];

    inode = inode_read(ino,buf);
    //free all block it used
    for(int i=0;i<inode->nblock;++i){
        block_free(inode->blocks[i]);
    }
    inode->type = FREE_INODE;
    inode_write(ino,buf);
}

/************************ data ************************/
void data_read(int k,char* buf){
    /* simply add a data_start */
    block_read(sblock->data_start+k,buf);
}

void data_write(int k,char* buf){
    block_write(sblock->data_start+k,buf);
}



/********************** directory **********************/
#define DIR_PER_BLOCKS (BLOCK_SIZE/sizeof(dir_t))

int dir_find_inode(int dir_ino,char *filename){
    char buf[BLOCK_SIZE];    // for block data
    char dir_buf[BLOCK_SIZE];// for inode_t
    inode_t* dir_inode;

    /* read inode struct of directory */
    dir_inode = inode_read(dir_ino,dir_buf);
    dir_t* dir_ptr = (dir_t *)buf;   
    int n=dir_inode->size/sizeof(dir_t);    // number of dir_t
    ASSERT(dir_inode->nblock <= D_BLOCK);
    for(int i=0;i<dir_inode->nblock;++i){
        data_read(dir_inode->blocks[i],buf);
        int block_dirs=MIN(DIR_PER_BLOCKS, n-i*DIR_PER_BLOCKS);
        /* read each dir_t */
        for(int k=0;k<block_dirs;++k){
            if(!my_strcmp(dir_ptr[k].filename,filename)){
                return dir_ptr[k].ino;
            }
        }
    }
    // no found
    return -1;
}

int dir_insert(int dir_ino, int file_index,char* filename){
    /* insert <filename> into dir,file_index is the index of file in inode blocks */
    inode_t *dir_inode;
    dir_t   *dir_ptr;
    char inode_buf[BLOCK_SIZE];
    char data_buf[BLOCK_SIZE];
    
    dir_inode=inode_read(dir_ino,inode_buf);
    ASSERT2(dir_inode->type==DIRECTORY,"dir_inode is not directory!!");
    /* get the index of new index,for example,now there are
     * 3 dir_t under dir, k would be 3. [0 1 2] are used,so 
     * 3 can be the new index.
     */
    int k=dir_inode->size / sizeof(dir_t);// number of dir_t
    /* if file is more than maximal size */
    if(k >= D_BLOCK * DIR_PER_BLOCKS)
        return -1;
    int ind=k/DIR_PER_BLOCKS;   // index of block
    int off=k%DIR_PER_BLOCKS;   // offset in the block

    if(ind >= dir_inode->nblock){
        /* Q:can a directory can use more than one block?? */
        /* more than one block */
        // how to deal? alloc new blocks?
        int new_block = block_alloc();
        if(new_block == -1){
            return -1;
        }
        dir_inode->blocks[ind] = new_block;
        dir_inode->nblock++;
        // ASSERT(0);
    }

    data_read(dir_inode->blocks[ind],data_buf); //read this block into data_buf
    dir_ptr=(dir_t*)data_buf;
    dir_ptr[off].ino=file_index;
    my_strcpy(filename,dir_ptr[off].filename);
    data_write(dir_inode->blocks[ind],data_buf);//write back

    dir_inode->size += sizeof(dir_t);
    // dir_inode->nlink++; // how about . and .. ?
    inode_write(dir_ino,inode_buf);
    return TRUE;  
}

int dir_remove_inode(int dir_ino,char *filename){
    inode_t* inode;
    dir_t*   dir_ptr;
    int      dir_num;
    char     inode_buf[BLOCK_SIZE];
    char     data_buf[BLOCK_SIZE];
    char     last_buf[BLOCK_SIZE];

    inode = inode_read(dir_ino,inode_buf);
    dir_ptr=(dir_t*)data_buf;
    dir_num=inode->size / sizeof(dir_t);
    for(int i=0; i<inode->nblock; ++i){
        data_read(inode->blocks[i],data_buf);
        /* number of dirs in this block */
        int block_dirs = MIN(DIR_PER_BLOCKS,dir_num-i*DIR_PER_BLOCKS);
        for(int j=0; j<block_dirs; ++j){
            /* find this inode */
            if(!my_strcmp(dir_ptr[j].filename,filename)){
                /* delete current inode,then use last dir_t filling the blank */
                int    last_block = inode->nblock-1;
                int    last_off   = (dir_num-1)%DIR_PER_BLOCKS;
                dir_t* last_ptr   = (dir_t *)last_buf;
                data_read(inode->blocks[last_block],last_buf);
                /* overwrite */
                dir_ptr[j] = last_ptr[last_off];
                data_write(inode->blocks[i],data_buf);

                /* if last block contain only one dir, now the block is free */
                if(last_off == 0){
                    block_free(inode->blocks[last_block]);
                    inode->nblock--;
                }
                inode->size -= sizeof(dir_t);
                inode_write(dir_ino,inode_buf);
                return 0;
            }
        }
    }
    /* no such directory */
    return -1;
}


/******************* file descriptor *******************/
int fd_open(int ino,int mode){
    for(int i=0;i<FD_SIZE;++i){
        if(fd_table[i].is_open==FALSE){
            //initial
            fd_table[i].is_open=TRUE;
            fd_table[i].mode=mode;
            fd_table[i].offset=0;
            fd_table[i].ino=ino;
            return i;
        }
    }//EndFor
    return -1;
}

void fd_close(int fd){
    fd_table[fd].is_open = FALSE;
}

/*
This function initializes the data structures and resources used by the file system subsystem,
and if it detects that the disk is already formatted, it automatically mounts it to the root
directory.  It is invoked at kernel initialization time, but before the block module (block.c)
is initialized.  So you need to invoke block_init in fs_init.  Note that by the time fs_init is
called, the disk is not necessarily formatted.  As a result, you need to devise a mechanism so
that a formatted disk is recognized (see fs_mkfs).

This function is the only non-syscall function you are required to implement.
*/
void
fs_init(void){
    block_init();
    /* More code HERE */
    block_read(SB_LOC,sb_buf); //read sblock into buf
    sblock=(sb_t*)sb_buf;
    if(sblock->magic_num != SB_MAGIC_NUMER){
        /* not formatted */
        fs_mkfs();
    }
    else{
        /* already formatted, mount to root directory */
        current_directory=ROOT_ADDR;
        bzero((char *)fd_table, sizeof(fd_table));
    }
}

int
fs_mkfs(void){
    char data_buf[BLOCK_SIZE];
    char inode_buf[BLOCK_SIZE];
    int  re;
    //zero out buf,and then use it to zero-out all blocks
    bzero_block(data_buf);   
    for(int i=0;i<FS_SIZE;++i){
        block_write(i,data_buf);
    }

    //super-block initialize
    bzero_block(sb_buf);
    sblock_init();
    sblock_write(sb_buf);

    //init bitmap
    /* bzero has been finished before */

    //create a root directory
    /* k starts from 0 and ino start from 1,so index+1==ino */
    inode_t* root;
    root=inode_read(ROOT_ADDR,inode_buf);//read inode into root(address of buf)
    inode_init(root,DIRECTORY);
    inode_write(ROOT_ADDR,inode_buf);//write back to disk

    
    re = dir_insert(ROOT_ADDR,ROOT_ADDR,"." );
    if(re == -1){
        inode_free(ROOT_ADDR);
        return -1;
    }    
    re = dir_insert(ROOT_ADDR,ROOT_ADDR,"..");
    if(re == -1){
        inode_free(ROOT_ADDR);
        return -1;
    }
    current_directory=ROOT_ADDR;
    bzero((char *)fd_table, sizeof(fd_table));
    return 0;
}

/*
Prototype:    int fs_open (char *filename, int flags);
Function description:

Given a filename, fs_open() returns a file descriptor, a small, non-negative integer 
for use in subsequent system calls (fs_read, fs_write, fs_lseek, etc.).  The file 
descriptor returned by a successful call will be the lowest-numbered file descriptor
 not currently open.

The parameter flags must include one of the following access modes:  FS_O_RDONLY, 
FS_O_WRONLY, FS_O_RDWR.  These request opening the file read-only, write-only, or 
read/write respectively.  The constants are defined in the file common.h.

Open returns the new file descriptor, or -1 if an error occurred.

If a non-existent file is opened for writing, it should be created.  An attempt to open
 a non-existent file read-only should fail.

To make your life easier, we assume filename passed to the syscalls can only be ".", ".."
, a directory, or a filename in the current directory.  So you don't have to parse the 
path as "/" separated directory and file names. You can also assume that the length of the
 filename (and dirname) will be less than 32 bytes (MAX_FILE_NAME). These assumptions remain
  the same for the following functions.

It is considered an error to open a directory in any mode besides FS_O_RDONLY.

You can use a shared file descriptor table. You do not need to worry about user management 
or access control lists.
 */

int 
fs_open( char *fileName, int flags) {
    int      fd;
    char     open_buf[BLOCK_SIZE];
    int      open_ino;
    inode_t *inode;
    bool_t is_new_file=FALSE;
    if(fileName == NULL)
        return -1;
    if(flags!=FS_O_RDONLY && flags!=FS_O_WRONLY && flags!=FS_O_RDWR)
        return -1;
    open_ino = dir_find_inode(current_directory,fileName);
    if(open_ino==-1){
        // file does not exist
        if(flags== FS_O_RDONLY)
            // read-only: shouldn't creat the file
            return -1;
        // otherwise,create a new inode
        open_ino = inode_create(FILE_TYPE);
        if(open_ino==-1){
            // no free inode_t
            return -1;
        }
        int re = dir_insert(current_directory,open_ino,fileName);
        if(re == -1){
            //can not insert
            inode_free(open_ino);
            return -1;
        }
        is_new_file = TRUE;
    }//EndIf no <filename>

    inode=inode_read(open_ino,open_buf); 

    if(inode->type == DIRECTORY && flags != FS_O_RDONLY){
        // fail if trying to write a directory
        return -1;
    }

    /* file descriptor */
    fd = fd_open(open_ino,flags);
    if(fd == -1){
        // no free file descriptor
        if(is_new_file){
            inode_free(open_ino);
        }
        return -1;
    }
    inode->n_open++;
    inode_write(open_ino,open_buf);
    return fd;
}

/*
 fs_close() closes a file descriptor, so that it no longer refers to any
 file and may be reused.  It returns zero on success, and -1 on failure.
 If the descriptor was the last reference to a -1ile which has been 
 removed using unlink, the file is deleted.
*/
int 
fs_close( int fd) {
    inode_t *inode;
    char close_buf[BLOCK_SIZE];
    int  close_ino;// inode number

    if(fd<0 || fd>=FD_SIZE)
        return -1;
    if(fd_table[fd].is_open==FALSE)
        return -1;

    close_ino = fd_table[fd].ino;
    inode = inode_read(close_ino,close_buf);

    fd_close(fd);
    /* when there is no link but also be opened in fd_table,it will not been free */
    if(inode->nlink ==0 && inode->n_open ==0){
        inode_free(close_ino);
    }
    else{
        inode_write(close_ino,close_buf);
    }
    return 0;
}

/*
fs_read() attempts to read up to count bytes from file descriptor
fd into the buffer starting at buf.  If count is zero, fs_read()
returns zero and has no other results.  On success, the number 
of bytes successfully read is returned, and the file position 
is advanced by this number.  It is not an error if this number 
is smaller than the number of bytes requested; this may happen 
for example because fewer bytes are actually available right now.
On error, -1 is returned. In the error case it is left unspecified
whether the file position changed.
*/

int 
fs_read( int fd, char *buf, int count) {
    fd_t*    read_fd;
    inode_t* inode;
    char     inode_buf[BLOCK_SIZE];
    char     data_buf[BLOCK_SIZE];   
    if(fd<0 || fd>FD_SIZE)
        return -1;
    if(count==0)
        /* success */
        return 0;
    if(count<0)
        return -1;
    if(buf == NULL)
        return -1;
    read_fd = fd_table + fd;//&fdtable[fd]
    /* should not be write-only */
    if(read_fd->mode==FS_O_WRONLY)
        return -1;
    if(read_fd->is_open==FALSE)
        return -1;

    /* read inode */
    inode = inode_read(read_fd->ino,inode_buf);
    if(read_fd->offset > inode->size){
        /* more than the size of file */
        return -2;  //how to do ?
    }
    if(count+read_fd->offset > inode->size)
        count=inode->size - read_fd->offset;

    /* start at this block */
    int block_start=read_fd->offset / BLOCK_SIZE;
    int read_count=0;
    for(int i=block_start; read_count<count; ++i){
        data_read(inode->blocks[i],data_buf);
        int off; // offset in the block
        int read_bytes;     // number of bytes to be read in current block
        int block_remain;   // remained bytes of this block
        int read_remain;    // remained bytes that need to be read
        off          = read_fd->offset % BLOCK_SIZE;
        block_remain = BLOCK_SIZE - off; 
        read_remain  = count- read_count;
        read_bytes   = MIN(block_remain,read_remain);
        // copy
        bcopy((unsigned char *)(data_buf+off  ), 
              (unsigned char *)(buf+read_count), read_bytes);
        read_fd->offset += read_bytes;
        read_count      += read_bytes;
    }
    return read_count;
}

/*
fs_write() writes up to count bytes to the file referenced by the
file descriptor fd from the buffer starting at buf.

On success, the number of bytes written from buf are returned 
(a number less than count can be returned), and the file position
 is advanced by this number.  On error, -1 is returned. It is an 
 error to attempt a write at a point beyond the maximum size of a
 file. It is an error if count is greater than zero but no bytes 
 were written.

A file of size zero should not take up any data blocks.
Writing padding (see fs_lseek()) should be all or nothing.
If count is zero, 0 will be returned without causing any other 
effects. 
 */

int 
fs_write( int fd, char *buf, int count) {
    fd_t*    write_fd;
    inode_t* inode;
    char     inode_buf[BLOCK_SIZE];
    char     data_buf[BLOCK_SIZE]; 
    if(fd<0 || fd>FD_SIZE)
        return -1;
    if(count==0)
        /* success */
        return 0;
    if(count<0)
        return -1;
    if(buf == NULL)
        return -1;
    write_fd = fd_table + fd;//&fdtable[fd]
    /* should not be write-only */
    if(write_fd->mode==FS_O_RDONLY)
        return -1;
    if(write_fd->is_open==FALSE)
        return -1;

    if(write_fd->offset >= D_BLOCK * BLOCK_SIZE)
        return -1;

     /* read inode */
    inode = inode_read(write_fd->ino,inode_buf);
    if(write_fd->offset > inode->size){
        /* more than the size of file */        
    }

    /* start at this block */
    int write_count=0;
    block_start=write_fd->offset / BLOCK_SIZE;

    for(int i=block_start; write_count<count && i < D_BLOCK; ++i){
        /* allocate now block */
        if(i >= inode->nblock){
            inode->blocks[i]=block_alloc();
            if(inode->blocks[i]==-1){
                /* may need to free all block in FOR-loop */
                return -1;
            }
            inode->nblock++;
        }
        
        data_read(inode->blocks[i],data_buf);
        int off; // offset in the block
        int write_bytes;     // number of bytes to be read in current block
        int block_remain;   // remained bytes of this block
        int write_remain;    // remained bytes that need to be write
        off          = write_fd->offset % BLOCK_SIZE;
        block_remain = BLOCK_SIZE - off; 
        write_remain = count- write_count;
        write_bytes  = MIN(block_remain,write_remain);
        /* write to buf */
        bcopy((unsigned char *)(buf+write_count),
              (unsigned char *)(data_buf+off)   ,write_bytes);
        /* write back to disk */
        data_write(inode->blocks[i],data_buf);
        write_fd->offset += write_bytes;
        write_count      += write_bytes;
    }
    if(inode->size < write_fd->offset){
        inode->size = write_fd->offset;
    }
    inode_write(write_fd->ino,inode_buf);
    return write_count;
}

/*
The fs_lseek() function repositions the offset of the open file 
associated with the file descriptor fd to the argument offset.

The fs_lseek() function allows the file offset to be set beyond
the end of file (but this does not change the size of the file).
If data is later written at this offset, the file is padded 
with '\0's in the intervening space.

Upon successful completion, fs_lseek() returns the resulting 
offset location as measured in bytes from the beginning of the 
file.  Otherwise, a value of -1 is returned.
 */
int 
fs_lseek( int fd, int offset) {
    fd_t* seek_fd;
    if(fd<0 || fd>FD_SIZE)
        return -1;
    if(offset < 0)
        return -1;
    seek_fd = &fd_table[fd];
    if(seek_fd->is_open==FALSE)
        return -1;
    seek_fd->offset = offset;
    return seek_fd->offset;
}

/*
fs_mkdir() attempts to create a directory named dirname.
It returns zero on success, or -1 if an error occurred.
fs_mkdir() should fail if the directory dirname already
exists.

New directories must contain "." and ".." entries. It is an
error to try to create a directory without them.
*/
int 
fs_mkdir( char *fileName) {
    int new_ino;
    int re;
    if(fileName == NULL)
        return -1;
    re=dir_find_inode(current_directory,fileName);
    if(re!=-1)
        /* returns -1 means no such file,which is correct */
        return -1;
    new_ino = inode_create(DIRECTORY);
    if(new_ino==-1)
        return -1;
    re=dir_insert(new_ino,new_ino,".");
    if(re == -1){
        inode_free(new_ino);
        return -1;
    }
    re=dir_insert(new_ino,current_directory,"..");
    if(re == -1){
        inode_free(new_ino);
        return -1;
    }
    re=dir_insert(current_directory,new_ino,fileName);
    if(re == -1){
        inode_free(new_ino);
        return -1;
    }
    return 0;
}


/*
fs_rmdir() deletes a directory, which must be empty.  
On success, zero is returned; on error, -1 is returned
(e.g. attempting to delete a non-empty directory).
*/
int 
fs_rmdir( char *fileName) {
    int      rm_ino;
    inode_t* inode;
    char     buf[BLOCK_SIZE];
    if(fileName == NULL)
        return -1;
    if(!my_strcmp(fileName,".") || !my_strcmp(fileName,".."))
        return -1;
    rm_ino = dir_find_inode(current_directory,fileName);
    if(rm_ino == -1)
        return -1;
    inode = inode_read(rm_ino,buf);
    if(inode->type != DIRECTORY)
        return -1;
    /* it's empty when dir only contain . and .. */
    int is_empty = (inode->size == 2*sizeof(dir_t));
    if(!is_empty)
        return -1;

    dir_remove_inode(current_directory,fileName);

    inode->nlink--;

    if(inode->nlink==0){
        inode_free(rm_ino);
    }
    else
        inode_write(rm_ino,buf);
    return 0;
}

/*
fs_cd() changes the current directory to that specified in 
dirname.  On success, zero is returned.  On error, -1 is returned.
*/
int 
fs_cd( char *dirName) {
    int cd_ino;
    if(!my_strcmp(dirName,"."))
        return 0;
    if(!my_strcmp(dirName,"..")){
        cd_ino = dir_find_inode(current_directory,"..");
        current_directory=cd_ino;
        return 0;
    }
    cd_ino = dir_find_inode(current_directory,dirName);
    if(cd_ino == -1)
        return -1;
    current_directory = cd_ino;
    return 0;
}

/*
fs_link() creates a new link (also known as a hard link) to an 
existing file oldpath.  If newpath exists it will not be overwritten.
The new name may be used exactly as the old one for any operation; 
both names refer to the same file and it is impossible to tell which
name was the "original."

On success, zero is returned.  On error, -1 is returned.  It is an 
error to use this function on a directory.

Note that because there are no "paths" beyond the current directory, 
the parent, or a child directory, oldpath and newpath are actually 
both filenames and can only be in the same directory.
 */

int 
fs_link( char *old_fileName, char *new_fileName) {
    char     inode_buf[BLOCK_SIZE];
    int      re;
    int      ino;
    inode_t* inode;

    if(old_fileName == NULL || new_fileName == NULL)
        return -1;
    /* new_fileName has been used */
    re=dir_find_inode(current_directory,new_fileName);
    if(re != -1)
        return -1;
    ino = dir_find_inode(current_directory,old_fileName);
    if(ino == -1)
        return -1;
    inode = inode_read(ino,inode_buf);
    /* only file is allowed */
    if(inode->type == DIRECTORY)
        return -1;
    //add new link
    re = dir_insert(current_directory,ino,new_fileName);
    if(re == -1)
        return -1;
    /* ino's information has been changed in dir_insert,so re-read is needed */
    inode = inode_read(ino,inode_buf);
    inode->nlink++;
    inode_write(ino,inode_buf);
    return 0;
}

int 
fs_unlink( char *fileName) {  
    int      ino;
    inode_t* inode;
    char     inode_buf[BLOCK_SIZE];
    if(fileName == NULL)
        return -1;
    ino = dir_find_inode(current_directory,fileName);
    if(ino == -1)
        return -1;
    inode = inode_read(ino,inode_buf);
    if(inode->type==DIRECTORY)
        return -1;
    dir_remove_inode(current_directory,fileName);
    /* ino's information has been changed,so reload */
    inode = inode_read(ino, inode_buf);
    inode->nlink--;
    if(inode->nlink==0){
        inode_free(ino);
    }
    else
        inode_write(ino,inode_buf);
    return 0;
}


/*
fs_stat() returns information about a file.  It returns a fileStat 
structure(defined in common.h), which contains the following fields:
typedef struct {
    int inodeNo;        
    short type;            
    char links;          
    int size;   
    int numBlocks;    
} fileStat;
Do not reuse this struct for your inodes.
 */
int 
fs_stat( char *fileName, fileStat *buf) {
    int ino;
    inode_t *inode;
    char inode_buf[BLOCK_SIZE];

    if(fileName == NULL)
        return -1;
    if(buf == NULL)
        return -1;
    ino = dir_find_inode(current_directory,fileName);
    if(ino == -1){
        return -1;
    }
    inode = inode_read(ino,inode_buf);
    buf->inodeNo   = ino;
    buf->type      = inode->type;
    buf->links     = inode->nlink;
    buf->size      = inode->size;
    buf->numBlocks = inode->nblock;
    return 0;
}
