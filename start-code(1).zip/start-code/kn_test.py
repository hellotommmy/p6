#!/usr/bin/python

import os, sys, subprocess
fs_size_bytes = 1048576

def spawn_lnxsh():
    global p
    p = subprocess.Popen('./lnxsh', shell=True, stdin=subprocess.PIPE)

def issue(command):
    p.stdin.write(command + '\n')

def check_fs_size():
    fs_size = os.path.getsize('disk')
    if fs_size > fs_size_bytes:
        print "** File System is bigger than it should be (%s) **" %(pretty_size(fs_size))

def do_exit():
    issue('exit')
    return p.communicate()[0]

def rw_tests():
    print '***** Read Tests *****'
    # print '# mkfs'
    issue('mkfs')
    # print '# create kn 10'
    issue('create kn 10')
    # print '# open kn 3    '
    issue('open kn 3    ')
    # print '# read 0 10    '
    issue('read 0 10    ') 
    # print '# write 0 hello'
    issue('write 0 hello') 
    # print '# lseek 0 20   '
    issue('lseek 0 20   ')
    # print '# write 0 world'
    issue('write 0 world')
    # print '# lseek 0 0    '
    issue('lseek 0 0    ')
    # print '# read  0 30   '
    issue('read  0 30   ')
    # print '#stat .'
    issue('stat .')
    # print '# mkdir fold'
    issue('mkdir fold')
    # print '#stat .'
    issue('stat .')
    # print '#rmdir .'
    issue('rmdir .')
    # print '#stat .'
    issue('stat .')
    print do_exit()
    print '***********************'
    sys.stdout.flush()

def link_tests():
    print '***** link Tests *****'
    issue('mkfs')
    issue('create f 0')
    issue('link f f1')
    issue('link f f2')
    issue('link f f3')
    issue('link f f4')
    issue('ls')
    issue('link f f5')
    issue('ls')
    print do_exit()
    print '***********************'
    sys.stdout.flush()

def rm_tests():
    print '***** rm Tests *****'
    issue('mkfs')
    issue('create f 0')
    issue('ls')
    issue('mkdir q1')
    issue('ls')
    issue('mkdir q2')
    issue('ls')
    issue('rmdir q1')
    issue('ls')
    issue('rmdir q2')
    issue('ls')
    print do_exit()
    print '***********************'
    sys.stdout.flush()

def large_tests():
    print '***** large tests *****'
    issue('mkfs')
    for i in xrange(256):
        issue('stat .')
        issue('mkdir deeper%d'%(i))
        issue('cd deeper%d'%(i))
    issue('ls')
    for i in xrange(256):
        issue('cd ..')
    print do_exit()
    print '***********************'
    sys.stdout.flush()

def main():
    # spawn_lnxsh()
    # rw_tests()

    # spawn_lnxsh()
    # link_tests()

    # spawn_lnxsh()
    # rm_tests()
    spawn_lnxsh()
    large_tests()

if __name__ == '__main__':
    print 'main'
    main()
