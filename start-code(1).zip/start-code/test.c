#include <stdio.h>
#include <stdlib.h>
void my_strcpy(char* src,char* dest){
    int i=0;
    while(src[i]!='\0'){
        dest[i]=src[i];
        i++;
    }
}

int my_strcmp(char *a,char *b){
    int i=0;
    while(a[i]!='\0' && b[i]!='\0'){
        if(a[i]>b[i])
            return 1;
        else if(a[i]<b[i])
            return -1;
        else
            i++;
    }
    if(a[i]>b[i])
        return 1;
    else if(a[i]<b[i])
        return -1;
    else 
        return 0;
}
typedef struct{
    int    ino;
    int    size;
    short  type;
    short  nlink;
    short  nblock;
    int    n_open;  // num of being opened in file descriptor
    int    blocks[11];
}inode_t;

typedef struct {
    short inode; // Corresponding inode index on disk
    char name[32 + 1]; // File name of the entry
    char _padding[29];
} entry_t;
typedef struct{
    int  ino;
    char filename[32];
    char padding[28];   //size==64
}dir_t;
int main(){
	// char a[]="hello,world!\n";
	// char b[]="hello,world!\n";
	// printf("%s\n",a);
	// printf("%d\n",my_strcmp(a,b));
    printf("%ld\n",sizeof(inode_t));
    printf("%ld\n",sizeof(entry_t));
    printf("%ld\n",sizeof(dir_t));
	return 0;
}