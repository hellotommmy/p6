/*
 * Author(s): <Nan Kang>
 * e-mail   : kangnan95@qq.com
 * Implementation of a Unix-like file system.
*/
#ifndef FS_INCLUDED
#define FS_INCLUDED

//number of sectors
#define FS_SIZE 2048

// #define NOTYPE    0
// #define DIRECTORY 1
// #define NORMAL    2

/* return code definition */
#define OK         0
#define ERROR     -1
#define SAME_NAME -2

typedef struct{
	int magic_num;	
	int size;
	/* bitmap */
	int map_start;
	int map_blocks;
	/* inode */
	int inode_start;
	int inode_num;
	int inode_blocks;
	/* data */
	int data_start;
	int data_blocks;
}sb_t;

#define D_BLOCK 8
#define I_BLOCK 3
/* exactly 64 bit */
typedef struct{
	int    ino;
	int    size;
	short  type;
	short  nlink;
	short  nblock;
	int    n_open;	// num of being opened in file descriptor
	int    blocks[D_BLOCK];
	int    in_blocks[I_BLOCK];
}inode_t;

typedef struct{
	bool_t is_open;	//using
	int    ino;
	int    offset;
	int    mode;
}fd_t;

typedef struct{
	int  ino;
	char filename[32];
	char padding[28];	//size==64
}dir_t;

void fs_init( void);
int fs_mkfs( void);
int fs_open( char *fileName, int flags);
int fs_close( int fd);
int fs_read( int fd, char *buf, int count);
int fs_write( int fd, char *buf, int count);
int fs_lseek( int fd, int offset);
int fs_mkdir( char *fileName);
int fs_rmdir( char *fileName);
int fs_cd( char *dirName);
int fs_link( char *old_fileName, char *new_fileName);
int fs_unlink( char *fileName);
int fs_stat( char *fileName, fileStat *buf);

#define MAX_FILE_NAME 32
#define MAX_PATH_NAME 256  // This is the maximum supported "full" path len, eg: /foo/bar/test.txt, rather than the maximum individual filename len.
#endif
